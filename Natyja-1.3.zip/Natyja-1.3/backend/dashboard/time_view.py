from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.cache import never_cache
@never_cache
def server_time(request):
    return JsonResponse({'epochMs': timezone.now().timestamp()*1000,'timeZone':'Asia/Bishkek'})

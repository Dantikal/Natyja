import {useEffect,useState} from 'react';
import {api} from '../api/client.js';
export function useServerTime(){
 const [now,setNow]=useState(null);
 useEffect(()=>{let alive=true,base=null,pending=false;const sync=async()=>{if(pending)return;pending=true;try{const start=performance.now();const {data}=await api.get('/dashboard/time/',{params:{nonce:Math.random()}});const end=performance.now();if(alive&&Number.isFinite(data.epochMs)){base={epoch:data.epochMs+(end-start)/2,at:end};setNow(new Date(base.epoch));}}catch{}finally{pending=false;}};
 const tick=setInterval(()=>{if(base&&alive)setNow(new Date(base.epoch+performance.now()-base.at));},250);const refresh=setInterval(sync,10000);const visible=()=>{if(!document.hidden)sync();};sync();document.addEventListener('visibilitychange',visible);return()=>{alive=false;clearInterval(tick);clearInterval(refresh);document.removeEventListener('visibilitychange',visible);};},[]);
 return now;
}

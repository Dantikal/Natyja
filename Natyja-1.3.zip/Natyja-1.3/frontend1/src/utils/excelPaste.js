export function parseExcelText(text){
 const rows=[[]];let value='',quoted=false;
 for(let i=0;i<text.length;i++){const ch=text[i];if(ch==='"'&&(quoted||value==='')){if(quoted&&text[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}else if(!quoted&&(ch==='\t'||ch==='\n'||ch==='\r')){rows.at(-1).push(value);value='';if(ch!=='\t'){if(ch==='\r'&&text[i+1]==='\n')i++;rows.push([]);}}else value+=ch;}
 rows.at(-1).push(value);if(rows.length>1&&rows.at(-1).length===1&&rows.at(-1)[0]==='')rows.pop();return rows;
}
export function parseExcelClipboard(data){
 const html=data.getData('text/html');
 if(html){const doc=new DOMParser().parseFromString(html,'text/html'),table=doc.querySelector('table');if(table){const rows=[...table.rows].map(row=>[...row.cells].map(cell=>{if(cell.colSpan>1||cell.rowSpan>1)throw Error('Сначала разъедините объединённые ячейки в Excel.');return cell.textContent.replace(/\u00a0/g,' ');}));if(rows.length)return rows;}}
 return parseExcelText(data.getData('text/plain'));
}
export function validatePasteShape(matrix,rowCount,colCount){if(!matrix.length||matrix.some(row=>row.length!==matrix[0].length))return 'Диапазон должен быть прямоугольным.';if(matrix.length>rowCount||matrix[0].length>colCount)return 'Диапазон не помещается. Выберите другую начальную ячейку или сначала добавьте строки и столбцы.';return null;}

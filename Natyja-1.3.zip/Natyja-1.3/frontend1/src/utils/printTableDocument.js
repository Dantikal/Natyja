export function printTableDocument(root,{paper="a3"}={}){
 const clone=root.cloneNode(true),original=[root,...root.querySelectorAll('*')],copies=[clone,...clone.querySelectorAll('*')];
 const properties=['font-family','font-size','font-weight','text-align','vertical-align','white-space','writing-mode','transform','border','border-collapse','padding','width','height','min-width','line-height'];
 original.forEach((node,index)=>{const copy=copies[index],style=getComputedStyle(node);if(node.matches('table,thead,tbody,tr,td,th,input,textarea,.lesson-schedule-top-header,.lesson-schedule-top-header__unit'))for(const key of properties)copy.style.setProperty(key,style.getPropertyValue(key));if(node.matches('input,textarea')){const text=document.createElement('span');text.textContent=node.value;Object.assign(text.style,{cssText:copy.style.cssText,display:'inline-block',border:'0',boxShadow:'none',background:'transparent',color:'#000',minHeight:'0',height:'auto',whiteSpace:'pre-wrap'});if(node.closest('td,th'))text.style.width='100%';copy.replaceWith(text);}});
 clone.querySelectorAll('button,.no-print,.module-table-actions,.dashboard-print-toolbar,.module-template-toolbar,.journal-horizontal-scroll').forEach(node=>node.remove());
 Object.assign(clone.style,{width:`${root.scrollWidth}px`,minWidth:'0',margin:'0',padding:'0',background:'#fff',color:'#000',overflow:'visible',transform:'none'});
 clone.querySelectorAll('.table-wrap').forEach(node=>Object.assign(node.style,{overflow:'visible',maxHeight:'none',height:'auto',border:'0'}));
 let sheets=[clone];
 const sourceTable=clone.querySelector('table');
 if(paper==='a4'&&sourceTable&&root.querySelector('.lesson-schedule-top-header')){
  const count=sourceTable.querySelectorAll('colgroup col').length;
  sheets=[];
  for(let start=2;start<count;start+=6){
   const sheet=clone.cloneNode(true),table=sheet.querySelector('table'),keep=new Set([0,1]);for(let c=start;c<Math.min(count,start+6);c++)keep.add(c);
   [...table.querySelectorAll('colgroup col')].forEach((col,i)=>{if(!keep.has(i))col.remove();});
   const occupied=[];
   [...table.rows].forEach((row,r)=>{occupied[r]??=[];let c=0;for(const cell of [...row.cells]){while(occupied[r][c])c++;const span=cell.colSpan,rs=cell.rowSpan;let retained=0;for(let x=c;x<c+span;x++){if(keep.has(x))retained++;for(let y=r;y<r+rs;y++){occupied[y]??=[];occupied[y][x]=true;}}if(!retained)cell.remove();else cell.colSpan=retained;c+=span;}});
   const width=[...table.querySelectorAll('colgroup col')].reduce((total,col)=>total+(parseFloat(col.style.width)||90),0);
   table.style.width=`${width}px`;table.style.minWidth='0';sheet.style.width=`${Math.max(900,width)}px`;
   sheets.push(sheet);
  }
 }
 const frame=document.createElement('iframe');Object.assign(frame.style,{position:'fixed',width:'1px',height:'1px',border:'0',left:'-10000px'});frame.title='Печать таблицы';
 frame.onload=async()=>{const doc=frame.contentDocument;await doc.fonts?.ready;for(const sheet of doc.querySelectorAll('.print-sheet')){const width=Math.max(sheet.scrollWidth,sheet.getBoundingClientRect().width);sheet.style.zoom=String(Math.min(1,(paper==='a3'?1500:1040)/width));}frame.contentWindow.addEventListener('afterprint',()=>setTimeout(()=>frame.remove(),0),{once:true});frame.contentWindow.focus();frame.contentWindow.print();};
 frame.srcdoc=`<!doctype html><html><head><title>Документ</title><style>@page{size:${paper==='a3'?'A3':'A4'} landscape;margin:10mm}html,body{margin:0;padding:0;background:#fff;color:#000}*{box-sizing:border-box;box-shadow:none!important;text-shadow:none!important}.print-sheet+.print-sheet{break-before:page}thead{display:table-header-group}tr{break-inside:avoid}table{border-collapse:collapse}td,th{color:#000;background:#fff}span{outline:0!important}input,textarea{border:0}</style></head><body>${sheets.map(sheet=>`<div class="print-sheet">${sheet.outerHTML}</div>`).join('')}</body></html>`;document.body.append(frame);
}
